/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package java_doc;

/**
 *
 * @author User
 */
public class Java_Doc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        Splash ss=new Splash();
        ss.setVisible(true);
        ss.setSize(650,650);
        ss.setResizable(true);
        
        try {
            for (int  i = 0; i <= 100; i++) {  
                Thread.sleep(40);
                ss.lbl.setText(Integer.toString(i)+"%");
                Home hh= new Home();
                if (i == 100) {
                    ss.dispose();
                    hh.show();
                }
                
                   
            }              
        }  catch (Exception e) {
    }
    }
}


